﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/*
namespace Laboratorio2
{
    internal class Laboratorio21
    {
        public static void Main()
        {
            //asignando valor a variable estática.
            MyClass.Valor = 1;
            Console.WriteLine(MyClass.Valor);
        }
    }

    public class MyClass
    {
        //declarando variable estática
        public static int Valor;
    }
}
*/