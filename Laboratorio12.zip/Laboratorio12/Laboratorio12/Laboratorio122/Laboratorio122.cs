﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Laboratorio12.Laboratorio122
{
    public partial class Laboratorio122 : Form
    {
        public Laboratorio122()
        {
            InitializeComponent();
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void Laboratorio122_Load(object sender, EventArgs e)
        {

        }

        private void btnPromedio_Click(object sender, EventArgs e)
        {
            double n1, n2, n3, promedio;
            n1 = Convert.ToDouble(txtNota1.Text);
            n2 = Convert.ToDouble(txtNota2.Text);
            n3 = Convert.ToDouble(txtNota3.Text);
            promedio = (n1 + n2 + n3) / 3;
            txtPromedio.Text = promedio.ToString();
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            txtNota1.Clear();
            txtNota2.Clear();
            txtNota3.Clear();
            txtPromedio.Clear();
        }

        private void InitializeComponent()
        {
            this.SuspendLayout();
            // 
            // Laboratorio122
            // 
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Name = "Laboratorio122";
            this.Load += new System.EventHandler(this.Laboratorio122_Load_1);
            this.ResumeLayout(false);

        }

        private void Laboratorio122_Load_1(object sender, EventArgs e)
        {

        }
    }
}
