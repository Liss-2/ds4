﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Laboratorio12
{
    internal class CalculoDistancia
    {
        public double Calcular(double velocidad, double tiempo)
        {
            return velocidad * tiempo;
        }
    }
}
