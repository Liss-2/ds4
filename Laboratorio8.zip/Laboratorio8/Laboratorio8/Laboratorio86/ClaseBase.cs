﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Laboratorio8.Laboratorio86
{
    internal class ClaseBase
    {
        public void test()
        {
            
        }

        public virtual void MasTest()
        {
            
        }   
    }
}
