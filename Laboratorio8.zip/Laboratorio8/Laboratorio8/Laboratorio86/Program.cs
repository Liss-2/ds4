﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Laboratorio8.Laboratorio86
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            Console.WriteLine("Corrio la aplicación");
            ClaseHijo obj = new ClaseHijo();
            obj.MasTest();
        }
    }
}
