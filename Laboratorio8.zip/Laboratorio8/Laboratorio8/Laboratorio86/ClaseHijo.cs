﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Laboratorio8.Laboratorio86
{
    internal class ClaseHijo : ClaseBase
    {
        public override void MasTest()
        {
            // No se puede sobreescribir porque la clase base lo tiene sellado (sealed)
            Console.WriteLine("Se ejecutó: Metodo sobreescrito en ClaseHijo");
        }
    }
}
