﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Laboratorio8.Laboratorio87
{
    internal class ClaseBase
    {
        public void test()
        {
            Console.WriteLine("Se ejecutó: Metodo test en ClaseBase");
        }
        public void MasTest()
        {
            Console.WriteLine("Se ejecutó: Metodo MasTest en ClaseBase");
        }
    }
}
