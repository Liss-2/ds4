﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Laboratorio8.Laboratorio87
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            Console.WriteLine("Corrio la aplicación");
            ClaseBase obj = new ClaseBase();
            obj.test();
            ClaseBase obj2 = new ClaseBase();
            obj2.MasTest();
            ClaseHijo obj3 = new ClaseHijo();
            obj3.MasTest();
            Console.WriteLine(obj + " / " + obj2 + " / " + obj3);
        }
    }
}
