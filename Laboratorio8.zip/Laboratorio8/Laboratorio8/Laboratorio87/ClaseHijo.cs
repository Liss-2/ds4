﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Laboratorio8.Laboratorio87
{
    internal class ClaseHijo : ClaseBase
    {
        public new void MasTest()
        {
            // Se oculta el metodo de la clase base
            Console.WriteLine("Se ejecutó: Metodo oculto en ClaseHijo");
        }
    }
}
