﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Laboratorio8.Laboratorio85
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            Coordenadas misCoords = new Coordenadas(10, 15);
            misCoords.VerCoordenadas();
        }
    }
}
