﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Laboratorio5
{
    internal class Laboratorio53
    {
        private static void Main(string[] args)
        {
            string[] frutas = { "manzana", "plátano", "naranja" };
            foreach (string fruta in frutas)
            {
                Console.WriteLine(fruta);

            }
        }
    }
}