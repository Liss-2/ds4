﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Laboratorio7.Laboratorio72
{
    internal class JuegoDeDados
    {
        private Dado dado1, dado2, dado3;

        public JuegoDeDados()
        {
            dado1 = new Dado();
            dado2 = new Dado();
            dado3 = new Dado();
        }   

        public void Jugar()
        {
            dado1.Tirar();
            dado2.Tirar();
            dado3.Tirar();
            dado1.Imprimir();
            dado2.Imprimir();
            dado3.Imprimir();
            if (dado1.RetornarValor() == dado2.RetornarValor() && dado2.RetornarValor() == dado3.RetornarValor())
            {
                Console.WriteLine("¡Felicidades! ¡Has ganado!");
            }
            else
            {
                Console.WriteLine("Lo siento, has perdido. Inténtalo de nuevo.");
            }
            Console.ReadKey();
        }
    }
}
