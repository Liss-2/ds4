﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Laboratorio4
{
    internal class Laboratorio45
    {
        static void Main(string[] args)
        {
            //Declaracion de variables
            int edad1;
            int edad2;
            int edad3;
            int edad4;
            int edad5 = 31;

            //Inicializacion de variables
            edad1 = edad2 = edad3 = edad4 = 32;

            Console.WriteLine("{0}, {1}, {2}, {3}, {4}", edad1, edad2, edad3, edad4, edad5);
        }
    }
}
