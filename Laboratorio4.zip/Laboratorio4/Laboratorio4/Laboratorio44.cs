﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Laboratorio4
{
    internal class Laboratorio44
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ingrese la nota del estudiante");
            float score = float.Parse(Console.ReadLine());
            if (score >= 70)
            {
                Console.WriteLine();
                Console.WriteLine($"Su nota es {score} ha aprobado");
            }
            else
            {
                Console.WriteLine();
                Console.WriteLine($"Su nota es {score} ha reprobado, debe repetir");
            }
        }
    }
}
