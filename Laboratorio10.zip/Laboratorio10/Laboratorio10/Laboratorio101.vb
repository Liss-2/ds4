﻿Module Laboratorio101

    Sub Main()

        Console.WriteLine("Hola")
        Console.WriteLine("Este es mi primer programa de consola")

    End Sub

End Module
