﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/*
namespace Laboratorio6
{
    class Laboratorio63
    {
        static void Main(String[] args)
        {
            try
            {
                int[] myNumbers = { 1, 2, 3 };
                Console.WriteLine(myNumbers[10]);
            }
            catch (Exception e)
            {
                Console.WriteLine("Algo salió mal, valide el indice del arreglo");
            }
            finally
            {

                Console.WriteLine("Continuacion de la aplicacion, luego del bloque try/catch");
            }
        }
    }
}
*/