﻿/*internal class Program
{
    private static void Main(string[] args)
    {
        Console.WriteLine("Hello, World!");
    }
}*/

class Program
{

    static void checkAge (int age)
    {
        if (age < 18)
        {
            throw new ArithmeticException("Acceso negado - No cumple con el criterio de edad");
        }
        else
        {
            Console.WriteLine("Acceso Concedido");
        }
    }

    static void main(string[] args)
    {
        checkAge(15);
    }
}